# -*- coding: utf-8 -*-
"""
Created on Mon Dec 18 12:27:10 2023

@author: diego
"""

import numpy as np
import matplotlib.pyplot as plt

N = 859500

def fn(n):
    return 1/n**2

n=np.linspace(0,125,125)

acepted = []
for i in range(N):
    a=np.random.randint(1,125)
    b=np.random.rand()
    
    if b <= fn(a):
        acepted.append(a)
