# -*- coding: utf-8 -*-
"""
Created on Mon Nov  6 11:42:22 2023

@author: diego
"""

import numpy as np
import pandas as pd
import random as rand
import matplotlib.pyplot as plt
import scipy.optimize as sco

# CALCULATION OF CLUSTERS/MM 
plt.close('all')

"""
Notes about notation:
    
book: reference to the Riegler text (sometimes I will directly reffer to its 
                                     bibliography as [] )
NIST: ESTAR data from NIST (well, ESTAR in this case, I can try to use ASTAR 2)
"""

#Load data and format----------------------------------------------------------
folder= 'NIST data/'
gas='Argon'         #gas name to choose the _NIST data
NISTdata=pd.read_csv(folder + gas + '_Sp.txt', delimiter='\t', header=4)

NISTdata.rename(columns={'MeV      ':'Energy [MeV]',
                         'MeV cm2/g':'dE/dx [MeV cm2/g]'},
                inplace=True)

NISTdata=NISTdata.drop(columns={'Unnamed: 2'})

#Manually introduce experimental data (from book)  --> This is just to make the W calculation (we need data)
gamma_book=np.array([4.0,3.5])
E_book=0.511*(gamma_book-1)                                                    #transform gamma to E
Ncluster=np.array([27.8,28.6])/10                                              #n cluster/mm


#W calculation----------------------------------------------------------------- 

"""
We are going to calculate the difference between the data points ([ERM69]) and 
the corresponding stopping power predicted by Bethe-Bloch curve:

In a first approach I am going to perform a linear extrapolation for the BB 
curve to match the energies, but I can consider two more options for a future:
    *FIXME*
    
    -Export NIST data with the relevant energies included (they do the extrapo)
    
    -Fit a function to NIST data. (I guess that this is more general but I am 
                                   too lazy for it)
"""
#Localize the energy range where we are moving on for every data point
E1_a=NISTdata.loc[NISTdata['Energy [MeV]']<E_book[0]].index[-1]
E1_b=(NISTdata.loc[NISTdata['Energy [MeV]']>E_book[0]]).index[0]

E2_a=NISTdata.loc[NISTdata['Energy [MeV]']<E_book[1]].index[-1]
E2_b=(NISTdata.loc[NISTdata['Energy [MeV]']>E_book[1]]).index[0]

#Linear fit through it
def linear(x,a,b):
    return a*x+b

xdata=[NISTdata.loc[E1_a]['Energy [MeV]'], NISTdata.loc[E1_b]['Energy [MeV]']]#, NISTdata.loc[E2_a]['Energy [MeV]']]
ydata=[NISTdata.loc[E1_a]['dE/dx [MeV cm2/g]'], NISTdata.loc[E1_b]['dE/dx [MeV cm2/g]']]#, NISTdata.loc[E2_a]['dE/dx [MeV cm2/g]']]
fit,_=sco.curve_fit(linear, xdata, ydata)

#Calculate dE/dx for data points energy
dEdx_fit=linear(E_book,*fit)

W=Ncluster/dEdx_fit
Wmean=np.mean(W)
print('\n\n')
print('RESULTS for the W factor in {}:'.format(gas))
print('* W_i factor:\t', W)
print('* W mean:\t\t', Wmean)
print('-'*59)

#PLOT--------------------------------------------------------------------------

fig, ax1=plt.subplots()

ax1.plot(NISTdata['Energy [MeV]'], NISTdata['dE/dx [MeV cm2/g]'], color='b', 
         label='NIST data')
ax1.set_xscale('log')


ax1.set_xlabel('E [MeV]')
ax1.set_ylabel('-dE/dx [MeVg$^{-1}cm^2$]')
ax1.set_title('Comparison for Ar-gas')

ax2=ax1.twinx()

ax2.errorbar(E_book, Ncluster, yerr=[0.3,0.5], fmt='o',color='r', 
             label='[ERM69] data')
ax2.set_ylabel('N cluster/mm for {}'.format(gas))
ax2.set_ylim([0,max(Ncluster)+Wmean])
ax2.set_xscale('log')

ax2.plot(NISTdata['Energy [MeV]'], Wmean*NISTdata['dE/dx [MeV cm2/g]'], 
         color='g', label='NIST x{}'.format(Wmean))

fig.legend()
fig.tight_layout()


#------------------------------------------------------------------------------
#CALCULATION OF THE AVG N OF CLUSTERS ACCORDING TO MUON ENERGY

"""
FIXME: I am setting a fix energy to the muon just to test. This has to be 
updated to a E distribution.

I can make here a try-except where if the E is in the range of NIST data we do 
the same as before, and if it is not we can extrapolate as a linear regression. 
I mean, it won't be too much larger than a few GeV... it should work
"""
Emuon=5 #MeV
We=25.7e-6 #Ionization energy for Ar

#This energy is higher than the data used from NIST, so I am just extrapolating
#extrapolate to linear y=mx+n
m_extr=(NISTdata['dE/dx [MeV cm2/g]'][80]-NISTdata['dE/dx [MeV cm2/g]'][78])/(NISTdata['Energy [MeV]'][80]-NISTdata['Energy [MeV]'][78])
n_extr=NISTdata['dE/dx [MeV cm2/g]'][80]-m_extr*NISTdata['Energy [MeV]'][80]

Ncluster_muon=(m_extr*Emuon+n_extr)*Wmean
print('\nFor a muon with {} MeV:\t'.format(Emuon), Ncluster_muon,'[clusters/mm]')

#------------------------------------------------------------------------------
#NUMBER ELECTRON PER CLUSTER AND PROBABILITY

k=np.linspace(1,32,32) #n of e- (from Riegler book)[FIS91]
probAr_data=np.array([65.6,15.0,6.4,3.5,2.25,1.55,1.05,0.81,0.61,0.49,0.39,0.3,
                 0.25,0.2,0.16,0.12,0.095,0.075,0.063]) #from here on it goes as ~1/n**2
probAr_extr=[]
for i in range(len(probAr_data), len(k)):
    probAr_extr.append(21.6/k[i]**2)

probAr_extr=np.array(probAr_extr)
probAr=np.concatenate((probAr_data,probAr_extr))
probAr=np.append(probAr,(100-sum(probAr)))
k=np.append(k,(len(k)+1))

#LA ULTIMA PROBABILIDAD ESTA PUESTA POR NORMALIZACION
acum=[]
#e- per cluster choice // random weighted
for i in range(10000):
    n_e=np.random.choice(a=k,p=probAr/100)
    acum.append(n_e)
    
plt.figure()
plt.hist(acum, bins=100, density=True)







